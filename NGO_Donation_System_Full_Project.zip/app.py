import os
from datetime import datetime
from functools import wraps

import qrcode
from dotenv import load_dotenv
from flask import Flask, flash, redirect, render_template, request, url_for
from flask_login import LoginManager, UserMixin, current_user, login_required, login_user, logout_user
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import check_password_hash, generate_password_hash
from werkzeug.utils import secure_filename

load_dotenv()

BASE_DIR = os.path.abspath(os.path.dirname(__file__))
UPLOAD_DIR = os.path.join(BASE_DIR, "static", "uploads")
QR_DIR = os.path.join(BASE_DIR, "static", "qr")
os.makedirs(UPLOAD_DIR, exist_ok=True)
os.makedirs(QR_DIR, exist_ok=True)

app = Flask(__name__)
app.config["SECRET_KEY"] = os.getenv("SECRET_KEY", "ngo-demo-secret-change-me")
app.config["SQLALCHEMY_DATABASE_URI"] = os.getenv(
    "DATABASE_URL",
    "sqlite:///" + os.path.join(BASE_DIR, "ngo_donation.db")
)
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
app.config["MAX_CONTENT_LENGTH"] = 8 * 1024 * 1024

db = SQLAlchemy(app)
login_manager = LoginManager(app)
login_manager.login_view = "login"

ALLOWED_IMAGES = {"png", "jpg", "jpeg", "webp"}


class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(120), nullable=False)
    email = db.Column(db.String(150), unique=True, nullable=False)
    phone = db.Column(db.String(30))
    password_hash = db.Column(db.String(255), nullable=False)
    role = db.Column(db.String(30), nullable=False)
    address = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    def set_password(self, password):
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        return check_password_hash(self.password_hash, password)


class Donation(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    donor_id = db.Column(db.Integer, db.ForeignKey("user.id"), nullable=False)
    ngo_id = db.Column(db.Integer, db.ForeignKey("user.id"), nullable=True)
    product_name = db.Column(db.String(150))
    quantity = db.Column(db.Integer, default=1)
    description = db.Column(db.Text)
    donation_type = db.Column(db.String(30), nullable=False)  # product / money
    amount = db.Column(db.Float, default=0)
    pickup_address = db.Column(db.Text)
    latitude = db.Column(db.Float)
    longitude = db.Column(db.Float)
    status = db.Column(db.String(40), default="Available for Pickup")
    payment_status = db.Column(db.String(40), default="Not Applicable")
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    donor = db.relationship("User", foreign_keys=[donor_id])
    ngo = db.relationship("User", foreign_keys=[ngo_id])


class VolunteerProfile(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("user.id"), unique=True, nullable=False)
    points = db.Column(db.Integer, default=0)
    badge = db.Column(db.String(80), default="New Volunteer")
    onboarded = db.Column(db.Boolean, default=False)
    user = db.relationship("User")


class ImpactProof(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    donation_id = db.Column(db.Integer, db.ForeignKey("donation.id"), nullable=False)
    ngo_id = db.Column(db.Integer, db.ForeignKey("user.id"), nullable=False)
    image_filename = db.Column(db.String(255), nullable=False)
    people_helped = db.Column(db.Integer, default=0)
    caption = db.Column(db.Text)
    uploaded_at = db.Column(db.DateTime, default=datetime.utcnow)

    donation = db.relationship("Donation")
    ngo = db.relationship("User")


@login_manager.user_loader
def load_user(user_id):
    return db.session.get(User, int(user_id))


def role_required(*roles):
    def decorator(view):
        @wraps(view)
        @login_required
        def wrapped(*args, **kwargs):
            if current_user.role not in roles:
                flash("You do not have permission to open that page.", "danger")
                return redirect(url_for("home"))
            return view(*args, **kwargs)
        return wrapped
    return decorator


@app.context_processor
def inject_counts():
    return {
        "available_pickups": Donation.query.filter_by(
            donation_type="product", status="Available for Pickup"
        ).count()
    }


@app.route("/")
def home():
    ngos = User.query.filter_by(role="ngo").order_by(User.created_at.desc()).limit(6).all()
    return render_template("home.html", ngos=ngos)


@app.route("/about")
def about():
    return render_template("about.html")


@app.route("/features")
def features():
    return render_template("features.html")


@app.route("/contact")
def contact():
    return render_template("contact.html")


@app.route("/ngos")
def ngos():
    data = User.query.filter_by(role="ngo").order_by(User.created_at.desc()).all()
    return render_template("ngos.html", ngos=data)


@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        name = request.form.get("name", "").strip()
        email = request.form.get("email", "").strip().lower()
        phone = request.form.get("phone", "").strip()
        password = request.form.get("password", "")
        role = request.form.get("role", "").strip().lower()
        address = request.form.get("address", "").strip()

        if not all([name, email, password, role]):
            flash("Please fill all required fields.", "danger")
            return render_template("register.html")

        if role not in {"donor", "volunteer", "ngo"}:
            flash("Invalid role.", "danger")
            return render_template("register.html")

        if User.query.filter_by(email=email).first():
            flash("Email already registered. Please login.", "warning")
            return redirect(url_for("login"))

        user = User(
            name=name,
            email=email,
            phone=phone,
            role=role,
            address=address,
        )
        user.set_password(password)
        db.session.add(user)
        db.session.commit()

        if role == "volunteer":
            profile = VolunteerProfile(user_id=user.id)
            db.session.add(profile)
            db.session.commit()

        flash("Registration successful. Please login.", "success")
        return redirect(url_for("login"))

    return render_template("register.html")


@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")
        user = User.query.filter_by(email=email).first()

        if not user or not user.check_password(password):
            flash("Invalid email or password.", "danger")
            return render_template("login.html")

        login_user(user)
        return redirect(url_for("dashboard"))

    return render_template("login.html")


@app.route("/logout")
@login_required
def logout():
    logout_user()
    flash("You have been logged out.", "success")
    return redirect(url_for("home"))


@app.route("/dashboard")
@login_required
def dashboard():
    if current_user.role == "ngo":
        return redirect(url_for("ngo_dashboard"))
    if current_user.role == "donor":
        return redirect(url_for("donor_dashboard"))
    if current_user.role == "volunteer":
        return redirect(url_for("volunteer_dashboard"))
    return redirect(url_for("home"))


@app.route("/donate", methods=["GET", "POST"])
@role_required("donor")
def donate():
    if request.method == "POST":
        donation_type = request.form.get("donation_type", "product")
        product_name = request.form.get("product_name", "").strip()
        quantity = int(request.form.get("quantity") or 1)
        description = request.form.get("description", "").strip()
        pickup_address = request.form.get("pickup_address", "").strip()
        latitude = request.form.get("latitude", "").strip()
        longitude = request.form.get("longitude", "").strip()
        amount = float(request.form.get("amount") or 0)

        if donation_type == "product" and not product_name:
            flash("Enter the product you want to donate.", "danger")
            return render_template("donate.html")

        if donation_type == "money" and amount <= 0:
            flash("Enter a valid donation amount.", "danger")
            return render_template("donate.html")

        donation = Donation(
            donor_id=current_user.id,
            product_name=product_name if donation_type == "product" else "Money Donation",
            quantity=quantity if donation_type == "product" else 1,
            description=description,
            donation_type=donation_type,
            amount=amount,
            pickup_address=pickup_address,
            latitude=float(latitude) if latitude else None,
            longitude=float(longitude) if longitude else None,
            status="Available for Pickup" if donation_type == "product" else "Payment Pending",
            payment_status="Pending" if donation_type == "money" else "Not Applicable",
        )
        db.session.add(donation)
        db.session.commit()

        if donation_type == "money":
            qr_text = f"NGO-DEMO-PAYMENT|Donation:{donation.id}|Amount:{amount:.2f}"
            img = qrcode.make(qr_text)
            img.save(os.path.join(QR_DIR, f"donation_{donation.id}.png"))
            flash("Money donation created. Scan the QR and use the demo payment confirmation.", "success")
            return redirect(url_for("payment", donation_id=donation.id))

        flash("Product donation created. Volunteers can now see the pickup alert.", "success")
        return redirect(url_for("donor_dashboard"))

    return render_template("donate.html")


@app.route("/payment/<int:donation_id>", methods=["GET", "POST"])
@role_required("donor")
def payment(donation_id):
    donation = Donation.query.get_or_404(donation_id)
    if donation.donor_id != current_user.id:
        flash("You cannot access this donation.", "danger")
        return redirect(url_for("donor_dashboard"))

    if request.method == "POST":
        donation.payment_status = "Payment Successful"
        donation.status = "Donation Confirmed"
        db.session.commit()
        flash("Payment marked as successful in the demo system.", "success")
        return redirect(url_for("donor_dashboard"))

    return render_template("payment.html", donation=donation)


@app.route("/donor")
@role_required("donor")
def donor_dashboard():
    donations = Donation.query.filter_by(donor_id=current_user.id).order_by(Donation.created_at.desc()).all()
    proofs = ImpactProof.query.join(Donation).filter(Donation.donor_id == current_user.id).order_by(
        ImpactProof.uploaded_at.desc()
    ).all()
    total_people = sum(p.people_helped for p in proofs)
    return render_template("donor_dashboard.html", donations=donations, proofs=proofs, total_people=total_people)


@app.route("/volunteer")
@role_required("volunteer")
def volunteer_dashboard():
    profile = VolunteerProfile.query.filter_by(user_id=current_user.id).first()
    if not profile:
        profile = VolunteerProfile(user_id=current_user.id)
        db.session.add(profile)
        db.session.commit()

    pickups = Donation.query.filter_by(
        donation_type="product", status="Available for Pickup"
    ).order_by(Donation.created_at.desc()).all()

    my_pickups = Donation.query.filter(
        Donation.donor_id.isnot(None),
        Donation.status.in_(["Pickup Assigned", "Picked Up", "Received by NGO", "Distributed"])
    ).order_by(Donation.created_at.desc()).all()

    return render_template(
        "volunteer_dashboard.html",
        profile=profile,
        pickups=pickups,
        my_pickups=my_pickups
    )


@app.route("/volunteer/pickup/<int:donation_id>", methods=["POST"])
@role_required("volunteer")
def volunteer_pickup(donation_id):
    donation = Donation.query.get_or_404(donation_id)
    if donation.status != "Available for Pickup":
        flash("This donation is no longer available.", "warning")
        return redirect(url_for("volunteer_dashboard"))

    donation.status = "Picked Up"
    profile = VolunteerProfile.query.filter_by(user_id=current_user.id).first()
    if not profile:
        profile = VolunteerProfile(user_id=current_user.id)
        db.session.add(profile)

    profile.points += 10
    profile.onboarded = True

    if profile.points >= 50:
        profile.badge = "Impact Champion"
    elif profile.points >= 30:
        profile.badge = "Community Hero"
    else:
        profile.badge = "Active Volunteer"

    db.session.commit()
    flash("Pickup marked successfully. Please hand the product to the NGO.", "success")
    return redirect(url_for("volunteer_dashboard"))


@app.route("/ngo")
@role_required("ngo")
def ngo_dashboard():
    volunteer_count = User.query.filter_by(role="volunteer").count()
    onboarded = VolunteerProfile.query.filter_by(onboarded=True).count()
    received = Donation.query.filter_by(status="Received by NGO").count()
    pending = Donation.query.filter_by(status="Available for Pickup").count()
    distributed = Donation.query.filter_by(status="Distributed").count()
    money_total = db.session.query(db.func.sum(Donation.amount)).filter(
        Donation.donation_type == "money",
        Donation.payment_status == "Payment Successful"
    ).scalar() or 0

    recent_donations = Donation.query.order_by(Donation.created_at.desc()).limit(10).all()
    proofs = ImpactProof.query.filter_by(ngo_id=current_user.id).order_by(ImpactProof.uploaded_at.desc()).all()
    people_helped = sum(p.people_helped for p in proofs)

    return render_template(
        "ngo_dashboard.html",
        volunteer_count=volunteer_count,
        onboarded=onboarded,
        received=received,
        pending=pending,
        distributed=distributed,
        money_total=money_total,
        recent_donations=recent_donations,
        proofs=proofs,
        people_helped=people_helped,
    )


@app.route("/ngo/receive/<int:donation_id>", methods=["POST"])
@role_required("ngo")
def ngo_receive(donation_id):
    donation = Donation.query.get_or_404(donation_id)
    if donation.status == "Picked Up":
        donation.status = "Received by NGO"
        donation.ngo_id = current_user.id
        db.session.commit()
        flash("Product marked as received by NGO.", "success")
    return redirect(url_for("ngo_dashboard"))


@app.route("/ngo/distribute/<int:donation_id>", methods=["GET", "POST"])
@role_required("ngo")
def ngo_distribute(donation_id):
    donation = Donation.query.get_or_404(donation_id)

    if request.method == "POST":
        file = request.files.get("image")
        caption = request.form.get("caption", "").strip()
        people_helped = int(request.form.get("people_helped") or 0)

        if not file or not file.filename:
            flash("Please select a distribution image.", "danger")
            return render_template("ngo_distribute.html", donation=donation)

        ext = file.filename.rsplit(".", 1)[-1].lower()
        if ext not in ALLOWED_IMAGES:
            flash("Allowed images: PNG, JPG, JPEG, WEBP.", "danger")
            return render_template("ngo_distribute.html", donation=donation)

        safe_name = secure_filename(file.filename)
        filename = f"donation_{donation.id}_{int(datetime.utcnow().timestamp())}_{safe_name}"
        file.save(os.path.join(UPLOAD_DIR, filename))

        proof = ImpactProof(
            donation_id=donation.id,
            ngo_id=current_user.id,
            image_filename=filename,
            people_helped=max(0, people_helped),
            caption=caption,
        )
        donation.status = "Distributed"
        donation.ngo_id = current_user.id
        db.session.add(proof)
        db.session.commit()

        flash("Distribution proof uploaded and impact updated.", "success")
        return redirect(url_for("ngo_dashboard"))

    return render_template("ngo_distribute.html", donation=donation)


@app.route("/tracking/<int:donation_id>")
@login_required
def tracking(donation_id):
    donation = Donation.query.get_or_404(donation_id)

    if current_user.role == "donor" and donation.donor_id != current_user.id:
        flash("Access denied.", "danger")
        return redirect(url_for("home"))

    if current_user.role == "ngo" and donation.ngo_id not in (None, current_user.id):
        flash("Access denied.", "danger")
        return redirect(url_for("home"))

    return render_template("tracking.html", donation=donation)


@app.route("/volunteer/certificate")
@role_required("volunteer")
def certificate():
    profile = VolunteerProfile.query.filter_by(user_id=current_user.id).first()
    return render_template("certificate.html", profile=profile)


@app.route("/seed-demo")
def seed_demo():
    """Create one demo NGO and one demo volunteer for local testing."""
    if not User.query.filter_by(email="ngo@example.com").first():
        ngo = User(name="Helping Hands NGO", email="ngo@example.com", phone="9000000001",
                   role="ngo", address="Chennai, Tamil Nadu")
        ngo.set_password("demo123")
        db.session.add(ngo)

    if not User.query.filter_by(email="volunteer@example.com").first():
        volunteer = User(name="Demo Volunteer", email="volunteer@example.com", phone="9000000002",
                         role="volunteer", address="Chennai, Tamil Nadu")
        volunteer.set_password("demo123")
        db.session.add(volunteer)
        db.session.flush()
        db.session.add(VolunteerProfile(user_id=volunteer.id, points=20, badge="Active Volunteer"))

    db.session.commit()
    flash("Demo accounts created. NGO: ngo@example.com / demo123 | Volunteer: volunteer@example.com / demo123", "success")
    return redirect(url_for("login"))


with app.app_context():
    db.create_all()


if __name__ == "__main__":
    app.run(debug=True)
